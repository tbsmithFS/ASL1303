<?
	class Students extends CI_Controller {
		function __construct() {
			parent::__construct();
			$this -> load -> model('student');
			$this -> load -> model('course');
			$this -> load -> model('utilities/utility');
		}

		function login() {
			if ($_POST) {
				$this -> load -> model('utilities/validate');

				$student_id	= $this -> input -> post('studentId', true);
				$password = $this -> input -> post('password', true);

				$student_data = $this -> student -> get($student_id);
				if (!$student_data) {
					echo 'error';
					return false;
				}

				$login_valid = $this -> validate -> login($password, $student_data['password']);
				if ($login_valid) {
					$session_data = array(
						'logged_in' => 1,
						'student_id' => $student_data['student_id']
					);
					$this -> session -> set_userdata($session_data);

					redirect(base_url() . 'students/home');
				}
				else {
					echo 'error';
					return false;
				}
			}
			else {
				$this -> utility -> load_view('students/login');
			}
		}

		function signup() {
			if ($_POST) {
				$student_id = $this -> input -> post('studentId', true);
				$password = $this -> input -> post('password', true);

				$student_data = $this -> student -> get($student_id);
				if ($student_data) {
					echo 'error';
					return false;
				}

				$data = array('student_id' => $student_id, 'password' => md5($password));

				$signup_successful = $this -> student -> insert($data);
				if ($signup_successful) {
					$this -> session -> set_userdata('logged_in', 1);
					$this -> session -> set_userdata('student_id', $student_id);

					redirect(base_url() . 'students/home');
				}
				else {
					echo 'error';
					return false;
				}
			}
			else {
				$this -> utility -> load_view('students/signup');
			}
		}

		function logout() {
			$this -> session -> sess_destroy();
			redirect(base_url() . 'home');
		}

		function home() {
			$this -> utility -> protect('teacher');

			$student_id = $this -> session -> userdata('student_id');

			$data['courses'] = $this -> course -> get_courses($student_id);

			$this -> utility -> load_view('students/home', $data);
		}

		function course() {
			$this -> utility -> protect('teacher');

			$student_id = $this -> session -> userdata('student_id');

			$course_id = $this -> uri -> segment(3);

			$data['courses'] = $this -> course -> get_courses($student_id);
			$data['grades'] = $this -> course -> get_grades_by_student($student_id);

			$this -> utility -> load_view('students/course', $data);
		}

		function new_course() {
			$post_data = $this -> input -> post();
			var_dump($post_data);
		}
	}

































