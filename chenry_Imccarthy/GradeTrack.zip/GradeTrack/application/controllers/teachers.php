<?
	class Teachers extends CI_Controller {
		function __construct() {
			parent::__construct();

			$this -> load -> model('teacher');
			$this -> load -> model('course');
			$this -> load -> model('utilities/utility');
		}

		function login() {
			if ($_POST) {
				$this -> load -> model('utilities/validate');

				$email = $this -> input -> post('email', true);
				$password = $this -> input -> post('password', true);

				$teacher_data = $this -> teacher -> get($email);
				if (!$teacher_data) {
					echo 'error';
					return false;
				}

				$login_valid = $this -> validate -> login($password, $teacher_data['password']);
				if ($login_valid) {
					$session_data = array(
						'logged_in' => 1,
						'teacher_id' => $teacher_data['teacher_id'],
						'email' => $teacher_data['email']
					);
					$this -> session -> set_userdata($session_data);

					redirect(base_url() . 'teachers/home');
				}
				else {
					echo 'error';
					return false;
				}
			}
			else {
				$this -> utility -> load_view('teachers/login');
			}
		}

		function signup() {
			if ($_POST) {
				$email = $this -> input -> post('email', true);
				$password = $this -> input -> post('password', true);

				$teacher_data = $this -> teacher -> get($email);
				if ($teacher_data) {
					echo 'error';
					return false;
				}

				$data = array('email' => $email, 'password' => md5($password));

				$signup_successful = $this -> teacher -> insert($data);
				if ($signup_successful) {
					$this -> session -> set_userdata('logged_in', 1);
					$this -> session -> set_userdata('email', $email);

					redirect(base_url() . 'teachers/home');
				}
				else {
					echo 'error';
					return false;
				}
			}
			else {
				$this -> utility -> load_view('teachers/signup');
			}
		}

		function logout() {
			$this -> session -> sess_destroy();
			redirect(base_url() . 'home');
		}

		function home() {
			$this -> utility -> protect('student');

			$teacher_id = $this -> session -> userdata('teacher_id');

			$data['courses'] = $this -> course -> get_courses($teacher_id);

			$this -> utility -> load_view('teachers/home', $data);
		}
	}

























