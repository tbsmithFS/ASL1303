<?
	class Courses extends CI_Controller {
		function __construct() {
			parent::__construct();

			$this -> load -> model('course');
			$this -> load -> model('utilities/utility');
		}

		function course() {
			$this -> utility -> protect('student');

			$teacher_id = $this -> session -> userdata('teacher_id');
			$course_id = (int) $this -> uri -> segment(3);
			
			$data['courses'] = $this -> course -> get_courses($teacher_id);
			$data['gradeables'] = $this -> course -> get_gradeables($course_id);

			$this -> utility -> load_view('teachers/course', $data);
		}

		function new_course() {
			$this -> utility -> protect('student');

			if ($_POST) {
$post_data = $this -> input -> post();
var_dump($post_data);
			}
			else {
				$teacher_id = $this -> session -> userdata('teacher_id');
				
				$data['courses'] = $this -> course -> get_courses($teacher_id);

				$this -> utility -> load_view('teachers/new_course', $data);
			}
		}

		function gradeable() {
			$this -> utility -> protect('student');

			$teacher_id = $this -> session -> userdata('teacher_id');
			$course_id = (int) $this -> uri -> segment(3);
			$gradeable_id = (int) $this -> uri -> segment(4);

			$data['courses'] = $this -> course -> get_courses($teacher_id);
			$data['grades'] = $this -> course -> get_grades_by_gradeable($course_id, $gradeable_id);

			$this -> utility -> load_view('teachers/gradeable', $data);
		}

		function gradeables() {
			$this -> utility -> protect('student');

			$teacher_id = $this -> session -> userdata('teacher_id');
			$course_id = (int) $this -> uri -> segment(3);

			$data['courses'] = $this -> course -> get_courses($teacher_id);
			$data['grades'] = $this -> course -> get_grades_by_course($course_id);

			$this -> utility -> load_view('teachers/gradeable', $data);
		}

		function update_grade() {
			$post_data = $this -> input -> post();	
			var_dump(json_encode($post_data));
		}

		function delete_grade() {
			$this -> utility -> protect('student');

			$course_id = (int) $this -> uri -> segment(3);
			$gradeable_id = (int) $this -> uri -> segment(4);
			$grade_id = (int) $this -> uri -> segment(5);

			$deleted = $this -> course -> delete_grade($grade_id);
			if ($deleted) {
				redirect(base_url() . 'courses/gradeable/' . $course_id);
			}
		}
	}