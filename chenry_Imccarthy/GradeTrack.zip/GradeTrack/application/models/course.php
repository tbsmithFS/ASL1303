<?
	class Course extends CI_Model {
		
		function __construct() {
			parent::__construct();
		}
 
		function get_courses($user_id) {
			$teacher = $this -> session -> userdata('teacher_id');
			if ($teacher) {
				$this -> db -> select() -> from('courses');
				$this -> db -> where('teacher_id', $user_id);
				$query = $this -> db -> get();
				return $query -> result_array();
			}
			else {
				$this -> db -> select('g.course_id, c.course_name') -> from('grades as g');
				$this -> db -> join('courses as c', 'g.course_id = c.course_id');
				$this -> db -> where('g.student_id', $user_id);
				$this -> db -> group_by('course_id');
				$query = $this -> db -> get();
				return $query -> result_array();
			}
		}

		function get_gradeables($course_id) {
			$this -> db -> select() -> from('gradeables');
			$this -> db -> where('course_id', $course_id);
			$query = $this -> db -> get();
			return $query -> result_array();
		}

		function get_grades_by_gradeable($course_id, $gradeable_id) {
			$this -> db -> select('g.student_id, c.course_id, g.gradeable_id, r.gradeable_name, g.grade_id, g.grade') -> from('courses as c');
			$this -> db -> join('grades as g', 'g.course_id = c.course_id');
			$this -> db -> join('students as s', 'g.student_id = s.student_id');
			$this -> db -> join('gradeables as r', 'r.gradeable_id = g.gradeable_id');
			$this -> db -> where(array('g.gradeable_id' => $gradeable_id, 'g.course_id' => $course_id));
			$query = $this -> db -> get();
			return $query -> result_array();
		}

		function get_grades_by_student($student_id) {
			$this -> db -> select('g.gradeable_name, g.weight, grade_id, grade') -> from('grades');
			$this -> db -> join('gradeables as g', 'g.gradeable_id = grades.gradeable_id');
			$this -> db -> where(array('student_id' => $student_id));
			$query = $this -> db -> get();
			return $query -> result_array();
		}

		function get_grades_by_course($course_id) {
			$this -> db -> select('g.student_id, c.course_id, g.gradeable_id, g.grade_id, g.grade') -> from('courses as c');
			$this -> db -> join('grades as g', 'g.course_id = c.course_id');
			$this -> db -> join('students as s', 'g.student_id = s.student_id');
			$this -> db -> where('c.course_id', $course_id);
			$query = $this -> db -> get();
			return $query -> result_array();
		}

		function delete_grade($grade_id) {
			$this -> db -> where('grade_id', $grade_id);
			$this -> db -> delete('grades');
			return $this -> db -> affected_rows();
		}
	}