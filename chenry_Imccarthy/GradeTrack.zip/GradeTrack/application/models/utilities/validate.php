<?
	class Validate extends CI_Model {

		function login($password, $stored_password) {
			if (md5($password) === $stored_password) {
				return true;
			}	
		}
	}