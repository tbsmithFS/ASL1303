<?
	class Utility extends CI_Model {
		function __construct() {
			parent::__construct();
		}

		function load_view($view, $data = array()) {
			$this -> load -> view('base/header');

			$logged_in = $this -> session -> userdata('logged_in');
			if ($logged_in) {
				$this -> load -> view('base/nav', $data);
			}

			$this -> load -> view($view, $data);
			$this -> load -> view('base/footer');
		}

		function protect($user) {
			$logged_in = $this -> session -> userdata('logged_in');
			if ($logged_in) {
				$student = $this -> session -> userdata($user . '_id');
				if ($student) {
					redirect(base_url() . $user . 's/home');
				}
			}
			else {
				redirect(base_url() . 'home');
			}
		}
	}