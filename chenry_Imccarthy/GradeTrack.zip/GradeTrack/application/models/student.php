<?
	class Student extends CI_Model {

		function __construct() {
			parent::__construct();
		}
		
		function get($student_id) {
			$this -> db -> select() -> from('students');
			$this -> db -> where('student_id', $student_id);
			$query = $this -> db -> get();
			return $query -> row_array();
		}

		function insert($data) {
			$this -> db -> insert('students', $data);
			return $this -> db -> affected_rows();
		}
	}