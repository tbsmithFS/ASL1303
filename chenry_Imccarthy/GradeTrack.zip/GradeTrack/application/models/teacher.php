<?
	class Teacher extends CI_Model {

		function __construct() {
			parent::__construct();
		}

		function get($email) {
			$this -> db -> select() -> from('teachers');
			$this -> db -> where('email', $email);
			$query = $this -> db -> get();
			return $query -> row_array();
		}

		function insert($data) {
			$this -> db -> insert('teachers', $data);
			return $this -> db -> insert_id();
		}
	}