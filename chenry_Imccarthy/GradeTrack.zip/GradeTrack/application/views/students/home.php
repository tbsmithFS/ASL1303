<section id="classContent">
    <h3>
        Pick a class
    </h3>
</section>