<section id="studentLogin">
	<h2 class="pageId">Student Login</h2>
            
	<form action="login" method="post" name="studentLogin" enctype="multipart/form-data">
		<ul>
			<li><label for="studentId">Student Id</label></li>
			<li><input type="text" id="studentId" name="studentId"/></li>
			<li><label for="password">Password</label></li>
			<li><input type="text" id="password" name="password"/></li>
                
			<li><input type="submit" name="submit" class="button"/></li>
			<li><a href="signup" class="button" style="color: black; padding:5px 10px">Not a Member?</a></li>
		</ul>
	</form>
</section>