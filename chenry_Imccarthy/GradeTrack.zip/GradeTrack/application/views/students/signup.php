<section id="studentSignup">
    <h2 class="pageId">Student Sign up</h2>
        
    <form action="signup" method="post" name="studentSignup" enctype="multipart/form-data">
        <ul>
            <li><label for="studentId">Student Id</label></li>
            <li><input type="text" id="studentId" name="studentId"/></li>
            <li><label for="password">Password</label></li>
            <li><input type="text" id="password" name="password"/></li>
            <li><label for="confirmPass">Confim Password</label></li>
            <li><input type="text" id="confirmPass" name="confirmPass"/></li>
            <li><input type="submit" name="submit" class="button"/></li>
            <li><a href="login" class="button" style="color: black; padding:5px 10px">Cancel</a></li>
        </ul>
    </form>
</section>