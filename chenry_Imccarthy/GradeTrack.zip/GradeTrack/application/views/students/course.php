<?
    $final_grade = 0;
    $weight = 0;

    foreach ($grades as $grade) {
       $final_grade += $grade['grade'];
       $weight += $grade['weight'];
    }

    $final_grade = ($final_grade / $weight) * 100;
?>

<section id="classContent">
    <h2 class="finalGrade">Final Grade: <?=$final_grade?>%</h2>
    
    <article>
        <h3>Assignments:</h3>
        <ul>

<?  foreach ($grades as $grade) {   ?>

        <li>
            <?=$grade['gradeable_name']?> <span>Grade: <?=$grade['grade']?></span>
        </li>        

<?  }   ?>

        </ul>
    </article>
</section>