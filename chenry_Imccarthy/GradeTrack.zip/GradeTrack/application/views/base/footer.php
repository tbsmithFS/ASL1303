			<footer>
	        	&copy; Gradetrack 2013
	        </footer>
	    </div>
	</body>
</html>