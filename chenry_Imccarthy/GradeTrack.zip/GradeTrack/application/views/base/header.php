<?
	$logged_in = $this -> session -> userdata('logged_in');
	$teacher = $this -> session -> userdata('email');
?>

<!doctype html>

<html>
	<head>
		<title>GradeTrack</title>
        <link rel="stylesheet" type="text/css" href="<?=base_url() . '/css/main.css'?>">
	</head>

	<body>
		<div id="wrapper">
	    	<header>
	        	<h1 class="logo">

					<?	if ($logged_in) {
							if ($teacher) {	?>

								<a href="<?=base_url() . 'teachers/home'?>">GradeTrack</a>

						<?	}
							else {	?>

								<a href="<?=base_url() . 'students/home'?>">GradeTrack</a>	

						<?	}
						}
						else {	?>

							<a href="<?=base_url() . 'home'?>">GradeTrack</a>

					<?	}	?>

	        	</h1>

        <?	if ($logged_in === 1) {	?>

	            <a href="<?=base_url() . 'students/logout'?>">Logout</a>
	            
	    <?	}	?>

	        </header> 