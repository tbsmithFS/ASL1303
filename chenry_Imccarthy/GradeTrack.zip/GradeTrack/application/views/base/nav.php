<div id="content">
<nav class="classNav">
	<ul>

<?	$teacher = $this -> session -> userdata('email');
	if ($teacher) {
		foreach ($courses as $course) {	?>

	        <li>
	            <a href="<?=base_url() . 'courses/course/' . $course['course_id']?>" class="button"><?=$course['course_name']?></a>
	        </li>

<?		}	?>

			<li>
				<a href="<?=base_url() . 'courses/new_course'?>" class="button">Add New</a>
			</li>

<?	}
	else {
		foreach ($courses as $course) {	?>

	        <li>
	            <a href="<?=base_url() . 'students/course/' . $course['course_id']?>" class="button"><?=$course['course_name']?></a>
	        </li>
	        
<?		}
	}	?>

	</ul>
</nav>