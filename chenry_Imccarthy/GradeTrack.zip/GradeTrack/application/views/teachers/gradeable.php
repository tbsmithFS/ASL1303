<section id="teacherClassContent">
    <h3 class="pageId"><?=$grades[0]['gradeable_name']?></h3>

<?  echo form_open('courses/update_grade'); ?>
<!--    <form action="<?site_url('courses/update_grade')?>" method="post" name="update_grade" enctype="multipart/form-data">
 -->        <ul>

<?  foreach ($grades as $grade) {   ?>

            <li>
                <ul>
                    <li>
                        <input type="text" name="student_id" value="<?=$grade['student_id']?>"/>
                    </li>
                    <li>
                        <input type="text" name="grade" value="<?=$grade['grade']?>" />
                    </li>
                    <li>
                        <a href="#">Delete</a>
                    </li>
                </ul>
            </li>

<?  }   ?>

        </ul>
        <input type="submit" value="Update" />
    </form>
</section>
</div>