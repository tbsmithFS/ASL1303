<section id="teacherSignup">
    <h2 class="pageId">Teacher Sign up</h2>
        
    <form action="signup" method="post" name="teacherSignup" enctype="multipart/form-data">
        <ul>
            <li><label for="email">Email</label></li>
            <li><input type="text" id="email" name="email"/></li>
            <li><label for="pass">Password</label></li>
            <li><input type="password" id="pass" name="pass"/></li>
            <li><label for="confirmPass">Confim Password</label></li>
            <li><input type="password" id="confirmPass" name="confirmPass"/></li>
            
            <li><input type="submit" name="submit" class="button"/></li>
            <li><a href="login" class="button">Cancel</a></li>
        </ul>
    </form>
</section>