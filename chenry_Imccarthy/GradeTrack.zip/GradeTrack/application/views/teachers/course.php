<section id="teacherClassContent">

    <h3 class="classView"></h3>

    <ul>

<?  if ($gradeables) {
        foreach ($gradeables as $gradeable) {   ?>

            <li>
                <a class='button' href="<?=base_url() . 'courses/gradeable/' . $gradeable['course_id'] . '/' . $gradeable['gradeable_id']?>"><?=$gradeable['gradeable_name']?></a>
            </li>

    <?  }   ?>

        <li>
            <a class='button' href="<?=base_url() . 'courses/gradeables/' . $gradeables[0]['course_id']?>">View All</a>
        </li>

<?  }   ?>

    </ul>
</section>