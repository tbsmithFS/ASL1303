<section>
    <h2 class="pageId">Add a Class</h2>
    <div id="content">    
    <?  echo form_open('courses/new_course'); ?>
            <fieldset>
                <legend class="classView">Class Information:</legend>
                <ul>
                    <li><label for="className">Class Name:</label><input type="text" id="className" name="className"/></li>
                    <li><label for="start">Start Date:</label><input type="text" id="start" name="start"/></li>
                    <li><label for="end">End Date:</label><input type="text" id="end" name="end"/></li>
                </ul>
            </fieldset>
            
            <fieldset> 
                <legend class="classView">Students:</legend>
                
                <ul>
                    <li><label for="studentName">Student Name:</label><input type="text" id="studentName" name="studentName"/></li>
                    <li><label for="studentNumber">Student Number:</label><input type="text" id="studentNumber" name="studentNumber"/></li>
                </ul>
            </fieldset>
            
            <fieldset>
                <legend class="classView">Assignments:</legend>
                <ul>
                    <li><label for="assignmentName">Assignment Name:</label><input type="text" id="assignmentName" name="assignmentName"/></li>
                    <li><label for="weight">Weight:</label><input type="text" id="weight" name="weight"/></li>
                </ul>
            </fieldset>
            
            <input type="submit" name="submit" class="button"/>
            <a href="<?=base_url() . 'teachers/home'?>" class="button">cancel</a>
        </form>
    </div>
</section>