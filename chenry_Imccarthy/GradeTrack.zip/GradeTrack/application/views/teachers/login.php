<section id="teacherLogin">
    <h2 class="pageId">Teacher Login</h2>
    
    <form action="login" method="post" name="teacherLogin" enctype="multipart/form-data">
        <ul>
            <li><label for="email">Email</label></li>
            <li><input type="text" id="email" name="email"/></li>
            <li><label for="password">Password</label></li>
            <li><input type="password" id="password" name="password"/></li>
            
            <li><input type="submit" name="submit" class="button"/></li>
            <li><a href="signup" class="button">Not a member?</a></li>
        </ul>
    </form>
</section>