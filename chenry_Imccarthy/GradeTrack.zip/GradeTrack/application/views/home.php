<section id="landing">
	<h2 id="landingLogo">GradeTrack</h2>
    <ul id="landingButtons">
        <li>
            <a href="students/login" class="button">Student</a>
        </li>
        <li style="font-size: 1.5em; font-weight: bold;">Or</li>
        <li>
            <a href="teachers/login" class="button">Teacher</a>
        </li>
    </ul>
</section>
