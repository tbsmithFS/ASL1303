<?
	class User extends CI_Model {

		/*============================================================================
		Methods to add and get users
		============================================================================*/

		function __construct() {
			parent::__construct();
		}

		function get($user) {
			$this -> db -> select() -> from('users');
			$this -> db -> where('user_name', $user);
			$query = $this -> db -> get();
			return $query -> row_array();
		}

		function insert($data) {
			$this -> db -> insert('users', $data);
			return $this -> db -> insert_id();
		}
		
		/*============================================================================
		Methods for the admin to remove and get users
		============================================================================*/
		
		function getAllAdmin() {
			$this -> db -> select() -> from('users');
			$query = $this -> db -> get();
			return $query -> result_array();
		}
		
		function remove($data) {
			$this->db->delete('users', array('user_id' => $data["user_id"]));
		}
		
	}