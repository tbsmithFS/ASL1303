<?
class Protector extends CI_Model {
	
	function __construct() {
		parent::__construct();
	}
	
	function protect(){
		$userLoggedIn = $this->session->userdata("loggedIn");
		if($this->session->userdata("loggedIn")){
			if( $userLoggedIn = '1'){
				
			}else{
				$this->load->helper('url');
				redirect(base_url()."Login/login", "refresh");
			};
		}else{
			$this->load->helper('url');
			redirect(base_url()."Login/login", "refresh");
		};
	}
}
?>