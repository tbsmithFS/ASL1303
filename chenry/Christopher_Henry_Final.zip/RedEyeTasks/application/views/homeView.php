<section id="content">
        	<h1>Welcome to RedEye</h1>
            <h2>your task soulutions made easy.</h2>
            
            <ul>
            	<li>Simple and Easy to use.</li>
                <li>Quick to get started.</li>
                <li>and best of all its FREE!</li>
            </ul>
            
            <img src="images/sc_demo.png" style="width:400px; height:300px;"/>
        </section>
        
        <section id="signup">
        	<h1>Sign up in 3 easy steps</h1>
            <form action="Login/newuser" method="post" enctype="multipart/form-data" name="signup_form">
                <ol>
                    <li><label for="username">Username:</label><br/>
                    <input type="text" placeholder="JonnyDoe" id="username" name="username"/></li>
                    <li><label for="pass">Password:</label><br/>
                    <input type="password" id="pass" name="pass"/></li>
                </ol>
                
                <p>Now click sign up and enjoy the easiest way to manage your tasks.</p>
            	<input type="submit" id="signupSubmit" disabled="disabled" name="submit" value=""/>
            </form>
            <p id="errors"></p>
        </section>
        
        <script type="text/javascript" src="css/js/dem.js"></script>
	<script type="text/javascript" src="css/js/main.js"></script>