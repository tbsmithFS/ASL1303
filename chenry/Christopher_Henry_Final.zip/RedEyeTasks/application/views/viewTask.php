<section id="taskContent">
    <h1 id="<? echo $task_id?>">Task Title:</h1>
    <p><? echo $title?></p>
    
    <h1>Task Description:</h1>
    <p><? echo $descrip?></p>
    
    <a href="../LoggedIn/home"><img src="../images/back.png"/></a>
</section>