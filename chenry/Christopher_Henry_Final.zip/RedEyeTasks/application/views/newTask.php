<section id="taskContent">
    <h1>Create Task:</h1>
    <form method="post" action="../Task/createTask" enctype="multipart/form-data" name="createTask">
        <ul>
            <li><label for="title">Title:</label><br/>
                <input type="text" placeholder="Task Title Here" id="title" name="title"/></li>
            <li><label for="descrip">Description:</label><br/>
            <textarea placeholder="type your information here" id="descrip" name="descrip"></textarea></li>
        </ul>
        <input type="submit" id="createTaskSubmit" name="submit" value=""/>
    </form>
</section>