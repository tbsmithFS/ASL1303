<div id="homeContent">
        	<a href="../Task/newTask" id="newTask"><img src="../images/newtask.png"/></a>
            
            <section>
            	<h1>Tasks:</h1>
                <ul>
                <?
                	foreach($tasks as $task){?>
                        <li class="task">
                            <div class="taskInfo">
                                <a href="../Task/viewTask?id=<? echo $task["task_id"]?>"><h2><? echo $task["title"]?></h2></a>
                                <p><? echo $task["descrip"]?></p>
                            </div>
                            <div class="taskButtons">
                                <a href="../Task/complete?id=<? echo$task["task_id"]?>"><img src="../images/completed.png"/></a>
                                <a href="../Task/editTask?id=<? echo$task["task_id"]?>"><img src="../images/Edit.png"/></a>
                            </div>
                        </li>
				<? }?>
       
                </ul>
            </section>