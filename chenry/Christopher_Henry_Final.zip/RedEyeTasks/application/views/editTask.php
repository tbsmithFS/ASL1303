<section id="taskContent">
	<form method="post" action="../Task/updateTask" enctype="multipart/form-data" name="editTask">
    <h1>Edit Task:</h1>
        <ul>
            <li><label for="title">Title:</label><br/>
                <input type="text" placeholder="Task Title Here" value="<? echo $title?>" id="title" name="title"/></li>
            <li><label for="descrip">Description:</label><br/>
            <textarea placeholder="type your information here" id="descrip" name="descrip"><? echo $descrip?></textarea></li>
        </ul>
        	<input type="hidden" value="<? echo $task_id?>" name="task_id"/>
            <input type="submit" id="editSubmit" name="submit" value=""/>
	</form>
</section>