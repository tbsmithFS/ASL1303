<section id="error">
    <p><? echo $error?></p>
</section>