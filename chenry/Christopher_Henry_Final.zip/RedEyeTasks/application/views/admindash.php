<div id="homeContent">
    <a href="../Task/newTask" id="newTask"><img src="../images/newtask.png"/></a>
    
    <section>
        <h1>Tasks:</h1>
        <ul>
        <?
            foreach($tasks as $task){?>
                <li class="task">
                    <div class="taskInfo">
                        <a href="../Task/viewTask?id=<? echo $task["task_id"]?>"><h2>User: <? echo $task["user_name"]?> [<? echo $task["title"]?>]</h2></a>
                        <p><? echo $task["descrip"]?></p>
                    </div>
                    <div class="taskButtons">
                        <a href="../Task/complete?id=<? echo$task["task_id"]?>"><img src="../images/completed.png"/></a>
                        <a href="../Task/editTask?id=<? echo$task["task_id"]?>"><img src="../images/Edit.png"/></a>
                    </div>
                </li>
                
        <? }?>

        </ul>
        
        <h1>Users:</h1>
        <p>*Please note there is no check so if you delete the user is gone be sure before you click the button.*</p>
        <ul>
        <? foreach($users as $user){
			if($user["user_id"] === "9999"){
			}else{?>
                <li class="user">
                    <div class="userInfo">
                        <h2>User: <? echo $user["user_name"]?></h2>
                    </div>
                    <div class="userButtons">
                        <a href="../Task/removeUser?id=<? echo$user["user_id"]?>"><img src="../images/delete.png"/></a>
                        
                    </div>
                </li>
            <? }?>
        <? }?>
        </ul>
    </section>