<? 
class Task extends CI_Controller {
	
		/*============================================================================
		Task Controls
		============================================================================*/

		function __construct() {
			parent::__construct();
			$this -> load -> model('tasks');
			$this -> load -> model('user');
			$this -> load -> model('protector');
			$this -> protector->protect();
		}
		
		function viewTask(){
			$data = $this->tasks->getTask($_GET["id"]);
			$this->load->view('loggedNav');
			$this->load->view('viewTask', $data);
			$this->load->view('footer');
		}
		
		function editTask(){
			$data = $this->tasks->getTask($_GET["id"]);
			$this->load->view('loggedNav');
			$this->load->view('editTask', $data);
			$this->load->view('footer');
		}
		
		function newTask(){
			$this->load->view('loggedNav');
			$this->load->view('newTask');
			$this->load->view('footer');
		}
		
		function createTask(){
			if ($_POST) {
				$data["title"] =$_POST["title"];
				$data["descrip"] = $_POST["descrip"];
				$data["user_id"] = $this->session->userdata("user_id");
				
				$this->tasks->createTask($data);
				
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
				
			}
			else {
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
		}
		
		function updateTask(){
			if ($_POST) {
				$data["title"] =$_POST["title"];
				$data["descrip"] = $_POST["descrip"];
				$data["task_id"] = $_POST["task_id"];
				$this->tasks->editTask($data);
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
			else {
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
		}
		
		function complete(){
			if (isset($_GET["id"])) {
				$data["task_id"] = $_GET["id"];
				$this->tasks->removeTask($data);
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
			else {
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
		}
		
		
		/*============================================================================
		User editing for admin
		============================================================================*/
		
		function removeUser(){
			if (isset($_GET["id"])) {
				$data["user_id"] = $_GET["id"];
				$this->user->remove($data);
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
			else {
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					$loadData["users"] = $this->user->
					
					$this->load->view('loggedNav');
					$this->load->view('admindash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
		}
		
}
?>