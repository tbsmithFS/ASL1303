<?
	class Home extends CI_Controller {
		
		/*============================================================================
		Home functionality
		============================================================================*/

		function __construct() {
			parent::__construct();
		}

		function index() {
			$this->load->view('nav');			
			$this -> load -> view('homeView');
			$this->load->view('footer');
		}
		
		function login() {
			$this->load->view('login');
		}
	}