<? 
class Login extends CI_Controller {
	
		/*============================================================================
		Login functionality
		============================================================================*/
		function __construct() {
			parent::__construct();
			$this -> load -> model('user');
			$this -> load -> model('tasks');
			$this -> load -> model('protector');
		}
		
		function login(){
			$this->load->view('loginNav');
			$this->load->view('login');
			$this->load->view('footer');
		}
		
		function loggedIn(){
			if($_POST){
				if($_POST["username"] != ""){
					$user_data = $this->user->get($_POST["username"]);
					if(count($user_data) > 1){
						$pass = md5($_POST["pass"]);
						if($user_data["user_id"] === "9999"){
							if($pass === $user_data["user_pass"]){
								$session_data = array("loggedIn" => 1, "user_id" => $user_data["user_id"]);
								$this->session->set_userdata($session_data);
								
								$data["tasks"] = $this->tasks->getAllAdmin();
								$data["users"] = $this->user->getAllAdmin();
								$this->load->view('loggedNav');
								$this->load->view('admindash', $data);
								$this->load->view('footer');
							}else{
								$this->load->view('loginNav');
								$data['error'] = "Password did not match.";
								$this->load->view('errors', $data);
								$this->load->view('login');
								$this->load->view('footer');
							}
						}else{
							if($pass === $user_data["user_pass"]){
								$session_data = array("loggedIn" => 1, "user_id" => $user_data["user_id"]);
								$this->session->set_userdata($session_data);
								
								$data["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
								$this->load->view('loggedNav');
								$this->load->view('dash', $data);
								$this->load->view('footer');
							}else{
								$this->load->view('loginNav');
								$data['error'] = "Password did not match.";
								$this->load->view('errors', $data);
								$this->load->view('login');
								$this->load->view('footer');
							}
						};
					}else{
						$this->load->view('loginNav');
						$data['error'] = "No such user found.";
						$this->load->view('errors', $data);
						$this->load->view('login');
						$this->load->view('footer');
					}
				}else{
					$this->load->view('loginNav');
					$this->load->view('login');
					$this->load->view('footer');
				}
			}else{
				$this->load->view('loginNav');
				$this->load->view('login');
				$this->load->view('footer');
			}
		}
		
		function logout(){
			$session_data = array("loggedIn" => 0, "user_id" => "");
			$this->session->set_userdata($session_data);
			$this->load->view('loginNav');
			$this->load->view('login');
			$this->load->view('footer');
		}
		
		/*============================================================================
		New User functionality
		============================================================================*/
		
		function newuser(){
			if($_POST){
				if($_POST["username"] != ""){
					$user_data = $this->user->get($_POST["username"]);
					if(count($user_data)<1){
						$pass = md5($_POST["pass"]);
						$user = array(
							"user_name" => $_POST["username"],
							"user_pass" => $pass
						);
						$this->user->insert($user);
						
						$user_data = $this->user->get($_POST["username"]);
						$session_data = array("loggedIn" => 1, "user_id" => $user_data["user_id"]);
						$this->session->set_userdata($session_data);
						
						$data["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
						
						$this->load->view('loggedNav');
						$this->load->view('dash', $data);
						$this->load->view('footer');
					}else{
						$session_data = array("loggedIn" => 0, "user_id" => "");
						$this->session->set_userdata($session_data);
						$this->load->view('loginNav');
						$data['error'] = "Username Already taken please login if already a user.";
						$this->load->view('errors', $data);
						$this->load->view('login');
						$this->load->view('footer');
					};
				}else{
					$this->load->helper('url');
					redirect(base_url(), "refresh");
				}
			}else{
				$session_data = array("loggedIn" => 0, "user_id" => "");
				$this->session->set_userdata($session_data);
				$this->load->view('loginNav');
				$this->load->view('login');
				$this->load->view('footer');
			}
		}
		
}
?>