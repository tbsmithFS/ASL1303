var dem = function (elems) {
	return new dem.prototype.init(elems);
};

dem.prototype ={
	init: function(elems){
		this.elements = (elems.nodeType) ? [elems] : elems;
	},

	elements:[],

	sayElem : function(){
		console.log(this.elements);
	},

	each : function(fn){
		for(var i = 0, j= this.elements.length; i < j; i++){
			fn.call(this.elements[i]);
		};
	},

	hasClass : function(name){
		var has = false;
		this.each(function(){//this reffers to the prototype
			var pattern = new RegExp("(^| )"+ name +"($| )");
			if(pattern.test(this.className)){//this reffers to the element
				has = true;
			};
		});
		return has;
	},

	addClass : function(name){
		this.each(function(){
			if(!dem(this).hasClass(name)){
				this.className += " " + name;
			};
		});
	},

	removeClass : function(name){
		this.each(function(){
			var pattern = new RegExp("(^| )"+ name +"($| )");
			if(dem(this).hasClass(name)){
				this.className = this.className.replace(pattern, "$1").replace(/ $/, "");
			};
		});
	},

	getStyle: function(prop){
		var elem = this.elements[0];
		if(elem.style[prop]){ 
			return elem.style[prop];
		}
		else if(elem.currentStyle){
			return elem.currentStyle[prop];
		}
		else if(document.defaultView){
			prop = prop.replace( /([A-Z])/g, "-$1" ).toLowerCase();
			return document.defaultView.getComputedStyle(elem, "").getPropertyValue(prop);
		}else{
			return 0;
		};
	}

};

dem.prototype.init.prototype = dem.prototype;