// JavaScript Document

(function(){
	var masterValid = false;
	
	//login and sign up elements
	var userName = document.getElementById("username");
	var pass = document.getElementById("pass");
	var conPass = document.getElementById("conPass");
	var submit = document.getElementById("signupSubmit");
	
	var error = document.getElementById("errors");
	
	//patterns to check by
	var namePat = new RegExp("^[a-zA-Z]{3}");
	
	var elements = [[userName,namePat],[pass, namePat]];
	
	dem(elements).each(function(){
			var elem = this[0];
			var pat = this[1];
			elem.onkeyup = function(e){
				console.log(masterValid);
			 	if(validate(elem,pat) === false){
		 			masterValid = false;
					error.innerHTML = "Please be sure that the user name and password are more than 3 characters.";
				}else{
					masterValid = true;
				};
				
				if(masterValid){
					submit.removeAttribute("disabled")
				}else{
					//nothing
				};
			};
	});

	var validate = function(input,pat){
		var pass = false;
		if(input.getAttribute("id") !== "conPass"){
			if(pat.test(input.value)){
				pass = true;
			};
		}else{
			if(pat.test(input.value)){
				if(pass.value===input.value){
					pass = true;
				};
			};
		};
		return pass;
	};
	
	
}());