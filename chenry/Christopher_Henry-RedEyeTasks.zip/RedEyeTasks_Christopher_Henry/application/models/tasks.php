<?
class Tasks extends CI_Model {
	function __construct() {
			parent::__construct();
		}
		
	function createTask($data){
		$this -> db -> insert('tasks', $data);
		return $this -> db -> affected_rows();
	}
	
	function getTask($taskid){
		$this->db->select()->from('tasks');
		$this->db->where('task_id', $taskid);
		$query = $this -> db -> get();
		return $query -> row_array();
	}
	
	function getAllAdmin(){
		$this->db->select()->from('tasks');
		$query = $this -> db -> get();
		return $query->result_array();
	}
	
	function getAll($userid){
		$this->db->select()->from('tasks');
		$this->db->where('user_id', $userid);
		$query = $this -> db -> get();
		return $query->result_array();
	}
	
	function editTask($data){
		//$this -> db -> update('tasks', $data);
		$dataPass = array(
               'title' => $data["title"],
               'descrip' => $data["descrip"]
            );
		$this->db->where('task_id', $data["task_id"]);
		$this->db->update('tasks', $dataPass); 
		return $this -> db -> affected_rows();
	}
	
	function removeTask($taskid){
		$this->db->delete('tasks', array('task_id' => $taskid["task_id"]));
	}
}
?>