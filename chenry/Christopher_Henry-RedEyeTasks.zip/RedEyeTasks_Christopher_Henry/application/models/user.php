<?
	class User extends CI_Model {

		function __construct() {
			parent::__construct();
		}

		function get($user) {
			$this -> db -> select() -> from('users');
			$this -> db -> where('user_name', $user);
			$query = $this -> db -> get();
			return $query -> row_array();
		}

		function insert($data) {
			$this -> db -> insert('users', $data);
			return $this -> db -> insert_id();
		}
	}