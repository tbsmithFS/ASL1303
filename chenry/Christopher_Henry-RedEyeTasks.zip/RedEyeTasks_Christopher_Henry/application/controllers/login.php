<? 
class Login extends CI_Controller {
		function __construct() {
			parent::__construct();
			$this -> load -> model('user');
			$this -> load -> model('tasks');
		}
		
		function login(){
			$this->load->view('loginNav');
			$this->load->view('login');
			$this->load->view('footer');
		}
		
		function loggedIn(){
			if($_POST["username"] != ""){
				$user_data = $this->user->get($_POST["username"]);
				if(count($user_data) > 1){
					$pass = md5($_POST["pass"]);
					if($user_data["user_id"] === "9999"){
						if($pass === $user_data["user_pass"]){
							$session_data = array("loggedIn" => 1, "user_id" => $user_data["user_id"]);
							$this->session->set_userdata($session_data);
							
							$data["tasks"] = $this->tasks->getAllAdmin();
							$this->load->view('loggedNav');
							$this->load->view('dash', $data);
							$this->load->view('footer');
						}else{
							$this->load->view('loginNav');
							echo "password did not match <br/>";
							echo "[$pass]<br/>";
							echo $_POST["pass"];
							$this->load->view('login');
							$this->load->view('footer');
						}
					}else{
						if($pass === $user_data["user_pass"]){
							$session_data = array("loggedIn" => 1, "user_id" => $user_data["user_id"]);
							$this->session->set_userdata($session_data);
							
							$data["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
							$this->load->view('loggedNav');
							$this->load->view('dash', $data);
							$this->load->view('footer');
						}else{
							$this->load->view('loginNav');
							echo "password did not match <br/>";
							echo "[$pass]<br/>";
							echo $_POST["pass"];
							$this->load->view('login');
							$this->load->view('footer');
						}
					};
				}else{
					$this->load->view('loginNav');
					echo "No such user found.";
					$this->load->view('login');
					$this->load->view('footer');
				}
			}else{
				$this->load->view('loginNav');
				$this->load->view('login');
				$this->load->view('footer');
			}
		}
		
		function logout(){
			$session_data = array("loggedIn" => 0, "user_id" => "");
			$this->session->set_userdata($session_data);
			$this->load->view('loginNav');
			$this->load->view('login');
			$this->load->view('footer');
		}
		
		function newuser(){
			if($_POST["username"] != ""){
				$user_data = $this->user->get($_POST["username"]);
				if(count($user_data)<1){
					$pass = md5($_POST["pass"]);
					$user = array(
						"user_name" => $_POST["username"],
						"user_pass" => $pass
					);
					$this->user->insert($user);
					
					$user_data = $this->user->get($_POST["username"]);
					$session_data = array("loggedIn" => 1, "user_id" => $user_data["user_id"]);
					$this->session->set_userdata($session_data);
					
					$data["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $data);
					$this->load->view('footer');
				}else{
					$session_data = array("loggedIn" => 0, "user_id" => "");
					$this->session->set_userdata($session_data);
					$this->load->view('loginNav');
					$this->load->view('login');
					$this->load->view('footer');
				};
			}else{
				$this->load->helper('url');
				redirect(base_url(), "refresh");
			}
		}
		
}
?>