<? 
class LoggedIn extends CI_Controller {

		function __construct() {
			parent::__construct();
			$this -> load -> model('tasks');
		}
		
		function home(){
			$data["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
			$this->load->view('loggedNav');
			$this->load->view('dash', $data);
			$this->load->view('footer');
		}
		
}
?>