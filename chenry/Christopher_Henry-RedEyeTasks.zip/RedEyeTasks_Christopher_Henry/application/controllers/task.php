<? 
class Task extends CI_Controller {

		function __construct() {
			parent::__construct();
			$this -> load -> model('tasks');
		}
		
		function viewTask(){
			$data = $this->tasks->getTask($_GET["id"]);
			$this->load->view('loggedNav');
			$this->load->view('viewTask', $data);
			$this->load->view('footer');
		}
		
		function editTask(){
			$data = $this->tasks->getTask($_GET["id"]);
			$this->load->view('loggedNav');
			$this->load->view('editTask', $data);
			$this->load->view('footer');
		}
		
		function newTask(){
			$this->load->view('loggedNav');
			$this->load->view('newTask');
			$this->load->view('footer');
		}
		
		function createTask(){
			if ($_POST) {
				$data["title"] =$_POST["title"];
				$data["descrip"] = $_POST["descrip"];
				$data["user_id"] = $this->session->userdata("user_id");
				
				$this->tasks->createTask($data);
				
				$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
				
				$this->load->view('loggedNav');
				$this->load->view('dash', $loadData);
				$this->load->view('footer');
				
			}
			else {
				$this->load->view('loggedNav');
				$this->load->view('dash');
				$this->load->view('footer');
			}
		}
		
		function updateTask(){
			if ($_POST) {
				$data["title"] =$_POST["title"];
				$data["descrip"] = $_POST["descrip"];
				$data["task_id"] = $_POST["task_id"];
				$this->tasks->editTask($data);
				
				$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
				
				$this->load->view('loggedNav');
				$this->load->view('dash', $loadData);
				$this->load->view('footer');
			}
			else {
				$this->load->view('loggedNav');
				$this->load->view('dash');
				$this->load->view('footer');
			}
		}
		
		function complete(){
			if (isset($_GET["id"])) {
				$data["task_id"] = $_GET["id"];
				$this->tasks->removeTask($data);
				if($this->session->userdata("user_id") === "9999"){
					$loadData["tasks"] = $this->tasks->getAllAdmin();
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');

				}else{
					$loadData["tasks"] = $this->tasks->getAll($this->session->userdata("user_id"));
					
					$this->load->view('loggedNav');
					$this->load->view('dash', $loadData);
					$this->load->view('footer');
				}
			}
			else {
				$this->load->view('loggedNav');
				$this->load->view('dash');
				$this->load->view('footer');
			}
		}
		
}
?>