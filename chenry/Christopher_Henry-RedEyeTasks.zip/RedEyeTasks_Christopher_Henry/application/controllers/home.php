<?
	class Home extends CI_Controller {

		function __construct() {
			parent::__construct();
		}

		function index() {
			$this->load->view('nav');			
			$this -> load -> view('homeView');
			$this->load->view('footer');
		}
		
		function login() {
			$this->load->view('login');
		}
	}