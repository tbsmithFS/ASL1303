<section id="loginContent">
    <form action="loggedIn" name="login" id="login" enctype="multipart/form-data" method="post">
    <ul>
        <li><label for="username">Username:</label><br/>
        <input type="text" placeholder="JonnyDoe" id="username" name="username"/></li>
        <li><label for="pass">Password:</label><br/>
        <input type="password" id="pass" name="pass"/></li>
    </ul>
    	<input type="submit" id="loginSubmit" disabled="disabled" name="submit" value="" />
    </form>
    <p id="errors"></p>
    
    <script type="text/javascript" src="../css/js/dem.js"></script>
	<script type="text/javascript" src="../css/js/login.js"></script>
</section>