<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>RedEyeTasks</title>
<link type="text/css" rel="stylesheet" href="../css/main.css"
</head>
<body>
	<script type="text/javascript" src="../css/js/dem.js"></script>
	<div id="wrapper">
        <nav>
            <div id="logo">
                <a href="../LoggedIn/home"><img src="../images/50x50logo.png"/>
                <h1>RedEye Tasks</h1></a>
            </div>
            <a href="../Login/logout" id="navLogin"><img src="../images/logoutbutton.png" /></a>
        </nav>