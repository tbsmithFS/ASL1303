(function($) {
	var doc = $(document);
	$("#tab").tabs();
	$(doc).tooltip();
	
	$('.em').keyup(function() {
		$('span.error-keyup-1').hide();
		var inputVal = $(this).val();
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if(!emailReg.test(inputVal)) {
			$(this).before('<span class="error error-keyup-1">Enter a valid email</span>');
		}
	});
	
	$('.un').keyup(function() {
		$('span.error-keyup-2').hide();
		var inputVal = $(this).val();
		var nameReg = /^[a-zA-Z0-9]+$/;
		if(!nameReg.test(inputVal)) {
			$(this).before('<span class="error error-keyup-2">Enter a valid username</span>');
		}
	});
	
	doc.on('click','#reg', function(e){
		$('span.error-keyup-3').hide();
		var username= $('.un').val();
		var password= $('.pwd').val();
		var email= $('.em').val();
		if(username=="" || password=="" || email==""){
			password ="";
			$(this).before('<span class="error error-keyup-3">Please enter all the fields.</span>');
		}else{
			return;
		};
		return false;
	});
	
	doc.on('click','.linkmiss', function(e){
		$('.linkfound').removeClass('active');
		$(this).addClass('active');
		return;
	});
	
	doc.on('click','#postSubmit', function(e){
		$('span.error-keyup-4').hide();
		var name= $('#missing-name').val();
		var location= $('#missing-location').val();
		var breed= $('#missing-breed').val();
		var color= $('#missing-color').val();
		var color= $('#missing-url').val();
		if(username=="" || password=="" || email=="" || cap==""){
		$(this).before('<span class="error error-keyup-4">Please enter all the fields.</span>');
		}else{
			return;
		};
		return false;
	});

	doc.on('click','.deletes', function(e){
 		 var yes=window.confirm("Are you sure you want to delete");
		 if(yes == true){
			 return;
		 }else{
			return false; 
		 }
	});
	
	doc.on('click','#found', function(e){
 		 var yes=window.confirm("Are you sure that want to move your dog to the found page?");
		 if(yes == true){
			 return;
		 }else{
			return false; 
		 }
	});
	

			
})(jQuery); 