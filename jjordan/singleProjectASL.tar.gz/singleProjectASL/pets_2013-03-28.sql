# ************************************************************
# Sequel Pro SQL dump
# Version 4004
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.25)
# Database: pets
# Generation Time: 2013-03-28 22:40:28 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table missings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `missings`;

CREATE TABLE `missings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `breed` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(50) DEFAULT NULL,
  `found` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `missings` WRITE;
/*!40000 ALTER TABLE `missings` DISABLE KEYS */;

INSERT INTO `missings` (`id`, `name`, `location`, `breed`, `color`, `gender`, `url`, `created`, `email`, `found`)
VALUES
	(32,'Tank','Maintland, FL','Pit bull mix','Gray / White','Male','pit.jpg','2013-03-27 01:29:11','tod@gmail.com',0),
	(33,'Boog','Winter Park,FL','Maltese','White','Male','maltese.jpg','2013-03-27 01:29:52','jjordan1775@gmail.com',0),
	(34,'Teddy','Apoka, FL','Lab','Dark Brown','Female','blacklab.jpg','2013-03-27 01:31:06','jb@gmail.com',0),
	(35,'Benji','Orlando,FL','Pug','Light Brown','Male','pug.jpg','2013-03-27 01:32:38','marineondubs@aol.com',0),
	(36,'Deville','Lakeland,FL','Dalmation','Black / White spots','Male','dalmation.jpg','2013-03-27 01:33:33','johnc@gmail.com',0),
	(37,'Tank','Maintland, FL','Pit bull mix','Brown','Male','IMG_1294.jpg','2013-03-27 02:45:13','jjordan1775@gmail.com',1),
	(38,'Buddy','Winter Park,FL','German Shepard','Light / Dark brown','Male','german.jpg','2013-03-27 02:46:25','rich@gmail.com',0);

/*!40000 ALTER TABLE `missings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `username`, `password`, `email`)
VALUES
	(1,'josh','1A1DC91C907325C69271DDF0C944BC72','marineondubs@aol.com'),
	(2,'juliana','1A1DC91C907325C69271DDF0C944BC72','jb@gmail.com'),
	(5,'admin','1A1DC91C907325C69271DDF0C944BC72','admin@gmail.com'),
	(6,'Todd','1A1DC91C907325C69271DDF0C944BC72','tod@gmail.com'),
	(7,'Jacob','1A1DC91C907325C69271DDF0C944BC72','jjordan1775@gmail.com'),
	(8,'John','1A1DC91C907325C69271DDF0C944BC72','johnc@gmail.com'),
	(10,'richard','1A1DC91C907325C69271DDF0C944BC72','rich@gmail.com'),
	(15,'joe','1A1DC91C907325C69271DDF0C944BC72','joe@gmail.com');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
